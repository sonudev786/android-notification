<?php


// Firebase API Key
define('FIREBASE_API_KEY', 'AIzaSyCZy2efY1j8A3QmTm79OjJFcVyUfcqN9GM');
